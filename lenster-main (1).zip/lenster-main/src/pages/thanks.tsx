import Thanks from '@components/Pages/Thanks';

export default Thanks;
