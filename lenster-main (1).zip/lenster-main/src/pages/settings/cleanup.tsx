import CleanupSettings from '@components/Settings/Cleanup';

export default CleanupSettings;
