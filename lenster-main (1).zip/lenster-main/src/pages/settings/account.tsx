import AccountSettings from '@components/Settings/Account';

export default AccountSettings;
