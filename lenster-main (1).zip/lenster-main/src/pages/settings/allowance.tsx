import AllowanceSettings from '@components/Settings/Allowance';

export default AllowanceSettings;
