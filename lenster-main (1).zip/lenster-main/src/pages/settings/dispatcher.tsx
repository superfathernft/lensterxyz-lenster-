import DispatcherSettings from '@components/Settings/Dispatcher';

export default DispatcherSettings;
