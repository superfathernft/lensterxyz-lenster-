import DeleteSettings from '@components/Settings/Delete';

export default DeleteSettings;
