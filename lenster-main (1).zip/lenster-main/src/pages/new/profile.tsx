import NewProfile from '@components/Profile/New';

export default NewProfile;
