import Stats from '@components/StaffTools/Stats';

export default Stats;
