import Mod from '@components/Mod';

export default Mod;
