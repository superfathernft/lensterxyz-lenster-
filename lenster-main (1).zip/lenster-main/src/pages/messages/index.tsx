import Messages from '@components/Messages';

export default Messages;
