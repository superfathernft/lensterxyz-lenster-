import Message from '@components/Messages/Message';

export default Message;
