import Report from '@components/Shared/Modal/Report';

export default Report;
