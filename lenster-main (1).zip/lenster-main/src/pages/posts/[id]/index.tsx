import ViewPublication from '@components/Publication';

export default ViewPublication;
