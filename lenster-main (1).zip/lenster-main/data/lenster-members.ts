export const lensterMembers = [
  '0x0d', // yoginth.lens
  '0x0c' // lenster.lens
];
