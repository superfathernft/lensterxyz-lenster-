export const mainnetGardeners = [
  '0x16', // davidev.lens
  '0x01', // lensprotocol
  '0x02', // aaveaave.lens
  '0x05', // stani.lens
  '0x06', // wagmi.lens
  '0x0210', // paris.lens
  '0x0d', // yoginth.lens
  '0x24', // bradorbradley.lens
  '0x8e', // christina.lens
  '0x0636', // jenny.lens
  '0xa1', // pealco.lens
  '0x30aa', // pablo.lens
  '0x4b', // ctrlaltf.lens
  '0xfc3f', // trallas24.lens
  '0x2ee4', // essah.lens
  '0x2d', // sasicodes.lens
  '0x0a', // jouni.lens
  '0x09' // nicolo.lens
];

export const testnetGardeners = [
  '0x01', // lensprotocol.test
  '0x02', // donosonaumczuk.test
  '0x06', // davidev.test
  '0x18', // devjoshstevens.test
  '0x15', // yoginth.test
  '0x038b' // 1653392689544.test
];
