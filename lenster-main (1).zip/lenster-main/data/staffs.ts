export const mainnetStaffs = [
  '0x16', // davidev.lens,
  '0x06', // wagmi.lens
  '0x05', // stani.lens
  '0x0d' // yoginth.lens
];

export const testnetStaffs = [
  '0x15' // yoginth.test
];
