export const hashflags: Record<string, string> = {
  lenster: 'lenster',
  lenstube: 'lenstube',
  bitcoin: 'bitcoin',
  btc: 'bitcoin',
  ethereum: 'ethereum',
  eth: 'ethereum',
  lens: 'lens',
  bts: 'bts',
  btsarmy: 'btsarmy',
  blm: 'blm',
  blacklivesmatter: 'blm',
  bhm: 'blm',
  pride: 'pride',
  lgbt: 'pride',
  voted: 'voted',
  hashtag: 'hashtag'
};
